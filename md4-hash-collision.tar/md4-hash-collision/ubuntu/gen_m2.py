# encoding: utf-8
import struct
import binascii
import time # For timing verification

# MD4 HELPER FUNCTIONS (Core MD4 logic - duplicated for standalone use)
def endian_unpack(byte_string):
    """Converts a byte string (little endian) to a list of 32-bit unsigned integers."""
    return [struct.unpack('<I', bytes(byte_string[i:i+4]))[0] for i in range(0, len(byte_string), 4)]

def left_rotate(n, b):
    """Circular left rotate for a 32-bit unsigned integer."""
    return ((n << b) | (n >> (32 - b))) & 0xffffffff

def F(x, y, z):
    """MD4 Boolean function F."""
    return (x & y) | (~x & z)

def G(x, y, z):
    """MD4 Boolean function G."""
    return (x & y) | (x & z) | (y & z)

def H(x, y, z):
    """MD4 Boolean function H."""
    return x ^ y ^ z

def FF_std(a, b, c, d, k, s, X):
    """MD4 standard round 1 function."""
    res = (a + F(b, c, d) + X[k]) & 0xffffffff
    return left_rotate(res, s)

def GG_std(a, b, c, d, k, s, X):
    """MD4 standard round 2 function."""
    res = (a + G(b, c, d) + X[k] + 0x5a827999) & 0xffffffff
    return left_rotate(res, s)

def HH_std(a, b, c, d, k, s, X):
    """MD4 standard round 3 function."""
    res = (a + H(b, c, d) + X[k] + 0x6ed9eba1) & 0xffffffff
    return left_rotate(res, s)

def calculate_md4(message_bytes):
    """Calculates the MD4 hash of a given byte string."""
    h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476] # Initial hash values

    original_byte_len = len(message_bytes)
    original_bit_len = original_byte_len * 8

    # Pre-processing (Padding)
    message_padded_array = bytearray(message_bytes)
    message_padded_array += b'\x80' # Append '1' bit
    
    padding_len = (56 - (original_byte_len + 1) % 64) % 64
    message_padded_array += b'\x00' * padding_len
    
    message_padded_array += struct.pack('<Q', original_bit_len)
    
    processed_message_bytes = bytes(message_padded_array)

    # Process the message in 512-bit (64-byte) chunks
    for i in range(0, len(processed_message_bytes), 64):
        chunk = processed_message_bytes[i:i+64]
        X = endian_unpack(chunk)

        A, B, C, D = h[0], h[1], h[2], h[3]

        # Round 1
        s1 = [3, 7, 11, 19]
        for j in range(16):
            if j % 4 == 0: A = FF_std(A, B, C, D, j, s1[j%4], X)
            elif j % 4 == 1: D = FF_std(D, A, B, C, j, s1[j%4], X)
            elif j % 4 == 2: C = FF_std(C, D, A, B, j, s1[j%4], X)
            elif j % 4 == 3: B = FF_std(B, C, D, A, j, s1[j%4], X)
        
        # Round 2
        s2 = [3, 5, 9, 13]
        k_order_g = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
        for j in range(16):
            idx = k_order_g[j]
            if j % 4 == 0: A = GG_std(A, B, C, D, idx, s2[j%4], X)
            elif j % 4 == 1: D = GG_std(D, A, B, C, idx, s2[j%4], X)
            elif j % 4 == 2: C = GG_std(C, D, A, B, idx, s2[j%4], X)
            elif j % 4 == 3: B = GG_std(B, C, D, A, idx, s2[j%4], X)

        # Round 3
        s3 = [3, 9, 11, 15]
        k_order_h = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
        for j in range(16):
            idx = k_order_h[j]
            if j % 4 == 0: A = HH_std(A, B, C, D, idx, s3[j%4], X)
            elif j % 4 == 1: D = HH_std(D, A, B, C, idx, s3[j%4], X)
            elif j % 4 == 2: C = HH_std(C, D, A, B, idx, s3[j%4], X)
            elif j % 4 == 3: B = HH_std(B, C, D, A, idx, s3[j%4], X)

        h[0] = (h[0] + A) & 0xffffffff
        h[1] = (h[1] + B) & 0xffffffff
        h[2] = (h[2] + C) & 0xffffffff
        h[3] = (h[3] + D) & 0xffffffff

    return "".join(struct.pack('<I', val).hex() for val in h)

# FUNCTION TO CREATE M2 FROM M1
def create_colliding_block_m2_from_m1(m1_bytes):
    """
    Creates the second message (M2) by introducing specific differences to M1.
    """
    x_words_m1 = list(endian_unpack(m1_bytes))
    x_words_m2 = x_words_m1[:] 
    
    x_words_m2[1] = (x_words_m2[1] + (2 ** 31)) % 2**32
    x_words_m2[2] = (x_words_m2[2] + ((2 ** 31) - (2 ** 28))) % 2**32
    x_words_m2[12] = (x_words_m2[12] - (2 ** 16)) % 2**32
    
    return b''.join([struct.pack('<I', val) for val in x_words_m2])

def main():
    print("[+] MD4 Collision Verifier: Generate M2 from M1, save M2, and Check Collision")
    
    m1_hex_input = input("Enter M1: ").strip()

    if len(m1_hex_input) != 128:
        print("Error: M1 hex string must be exactly 128 characters long.")
        return

    try:
        m1_bytes = binascii.unhexlify(m1_hex_input)
    except binascii.Error:
        print("Error: Input M1 string is not a valid hex string.")
        return

    if len(m1_bytes) != 64:
        print("Error: M1 after conversion is not 64 bytes long.") # Should not be reached if hex length is 128
        return

    print(f"\nReceived M1 (hex): {m1_hex_input}")

    # Generate M2 from M1
    m2_bytes = create_colliding_block_m2_from_m1(m1_bytes)
    m2_hex = binascii.hexlify(m2_bytes).decode()
    
    try:
        with open("m2.txt", "w") as f:
            f.write(m2_hex)
        print(f"Generated M2 (hex) and saved to m2.txt: {m2_hex}")
    except IOError:
        print("Error: Could not write M2 to m2.txt. Please check permissions.")
        print(f"Generated M2 (hex): {m2_hex}") # Print to console as fallback


    # Calculate hashes
    start_hash_time = time.perf_counter()
    hash_m1 = calculate_md4(m1_bytes)
    hash_m2 = calculate_md4(m2_bytes)
    hash_duration = time.perf_counter() - start_hash_time

    print(f"(Hashing took {hash_duration:.4f} seconds)")


    if hash_m1 == hash_m2:
        if m1_bytes != m2_bytes:
            print("Saved m2 in m2.txt")
            
            m1_words_hex = [m1_hex_input[i:i+8] for i in range(0, len(m1_hex_input), 8)]
            m2_words_hex = [m2_hex[i:i+8] for i in range(0, len(m2_hex), 8)]
            diff_display_m1 = []
            diff_display_m2 = []
            
            for i in range(len(m1_words_hex)):
                if m1_words_hex[i] != m2_words_hex[i]:
                    diff_display_m1.append(f"[{m1_words_hex[i]}]")
                    diff_display_m2.append(f"[{m2_words_hex[i]}]")
                else:
                    diff_display_m1.append(m1_words_hex[i])
                    diff_display_m2.append(m2_words_hex[i])

        else:
            print("\nUNEXPECTED ERROR: M1 and M2 are identical. This is not a true collision.")
    else:
        print("\nFAILURE: M1 and M2 do NOT have the same MD4 hash.")
        print("This should not happen if M1 was generated correctly by the first script and represents a valid collision candidate.")

if __name__ == "__main__":
    main()

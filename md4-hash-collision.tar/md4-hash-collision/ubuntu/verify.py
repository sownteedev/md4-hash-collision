# encoding: utf-8
import struct
import binascii
import os # For checking if files exist

# ANSI escape codes for colors
COLOR_RED = '\033[91m'
COLOR_GREEN = '\033[92m'
COLOR_RESET = '\033[0m'

# --- MD4 Core Implementation ---
def endian_unpack(byte_string):
    return [struct.unpack('<I', bytes(byte_string[i:i+4]))[0] for i in range(0, len(byte_string), 4)]

def left_rotate(n, b):
    return ((n << b) | (n >> (32 - b))) & 0xffffffff

def F(x, y, z): return (x & y) | (~x & z)
def G(x, y, z): return (x & y) | (x & z) | (y & z)
def H(x, y, z): return x ^ y ^ z

def FF_std(a, b, c, d, k, s, X):
    res = (a + F(b, c, d) + X[k]) & 0xffffffff
    return left_rotate(res, s)

def GG_std(a, b, c, d, k, s, X):
    res = (a + G(b, c, d) + X[k] + 0x5a827999) & 0xffffffff
    return left_rotate(res, s)

def HH_std(a, b, c, d, k, s, X):
    res = (a + H(b, c, d) + X[k] + 0x6ed9eba1) & 0xffffffff
    return left_rotate(res, s)

def calculate_md4(message_bytes):
    h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
    original_byte_len = len(message_bytes)
    original_bit_len = original_byte_len * 8

    message_padded_array = bytearray(message_bytes)
    message_padded_array += b'\x80'
    padding_len = (56 - (original_byte_len + 1) % 64) % 64
    message_padded_array += b'\x00' * padding_len
    message_padded_array += struct.pack('<Q', original_bit_len)
    processed_message_bytes = bytes(message_padded_array)

    for i in range(0, len(processed_message_bytes), 64):
        chunk = processed_message_bytes[i:i+64]
        X = endian_unpack(chunk)
        A, B, C, D = h[0], h[1], h[2], h[3]

        s1 = [3, 7, 11, 19]
        for j in range(16):
            if j % 4 == 0: A = FF_std(A, B, C, D, j, s1[j%4], X)
            elif j % 4 == 1: D = FF_std(D, A, B, C, j, s1[j%4], X)
            elif j % 4 == 2: C = FF_std(C, D, A, B, j, s1[j%4], X)
            elif j % 4 == 3: B = FF_std(B, C, D, A, j, s1[j%4], X)
        
        s2 = [3, 5, 9, 13]
        k_order_g = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
        for j in range(16):
            idx = k_order_g[j]
            if j % 4 == 0: A = GG_std(A, B, C, D, idx, s2[j%4], X)
            elif j % 4 == 1: D = GG_std(D, A, B, C, idx, s2[j%4], X)
            elif j % 4 == 2: C = GG_std(C, D, A, B, idx, s2[j%4], X)
            elif j % 4 == 3: B = GG_std(B, C, D, A, idx, s2[j%4], X)

        s3 = [3, 9, 11, 15]
        k_order_h = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
        for j in range(16):
            idx = k_order_h[j]
            if j % 4 == 0: A = HH_std(A, B, C, D, idx, s3[j%4], X)
            elif j % 4 == 1: D = HH_std(D, A, B, C, idx, s3[j%4], X)
            elif j % 4 == 2: C = HH_std(C, D, A, B, idx, s3[j%4], X)
            elif j % 4 == 3: B = HH_std(B, C, D, A, idx, s3[j%4], X)

        h[0] = (h[0] + A) & 0xffffffff
        h[1] = (h[1] + B) & 0xffffffff
        h[2] = (h[2] + C) & 0xffffffff
        h[3] = (h[3] + D) & 0xffffffff
    return "".join(struct.pack('<I', val).hex() for val in h)
# --- End of MD4 Core Implementation ---

def read_hex_from_file(filename):
    """Reads a hex string from a file."""
    if not os.path.exists(filename):
        print(f"{COLOR_RED}Error: File '{filename}' not found.{COLOR_RESET}")
        return None
    try:
        with open(filename, 'r') as f:
            hex_string = f.read().strip()
        # Validate if it's a hex string of expected message length (128 chars for 64 bytes)
        if len(hex_string) != 128:
            print(f"{COLOR_RED}Error: Content of '{filename}' is not 128 hex characters long.{COLOR_RESET}")
            return None
        # Further validation to ensure it's a valid hex string
        int(hex_string, 16) # This will raise ValueError if not valid hex
        return hex_string
    except ValueError:
        print(f"{COLOR_RED}Error: Content of '{filename}' is not a valid hex string.{COLOR_RESET}")
        return None
    except IOError:
        print(f"{COLOR_RED}Error: Could not read file '{filename}'.{COLOR_RESET}")
        return None

def compare_and_print_messages_colored(m1_hex, m2_hex):
    """Compares two message hex strings word by word and prints them with colors."""
    print("\n--- Comparing M1 and M2 (Messages) ---")
    
    m1_words = [m1_hex[i:i+8] for i in range(0, len(m1_hex), 8)]
    m2_words = [m2_hex[i:i+8] for i in range(0, len(m2_hex), 8)]

    if len(m1_words) != len(m2_words): # Should not happen if input validation is correct
        print(f"{COLOR_RED}Error: Messages have different word counts after splitting.{COLOR_RESET}")
        return

    m1_colored_parts = []
    m2_colored_parts = []

    for i in range(len(m1_words)):
        if m1_words[i] == m2_words[i]:
            m1_colored_parts.append(f"{COLOR_GREEN}{m1_words[i]}{COLOR_RESET}")
            m2_colored_parts.append(f"{COLOR_GREEN}{m2_words[i]}{COLOR_RESET}")
        else:
            m1_colored_parts.append(f"{COLOR_RED}{m1_words[i]}{COLOR_RESET}")
            m2_colored_parts.append(f"{COLOR_RED}{m2_words[i]}{COLOR_RESET}")
    
    print("M1:")
    for i in range(0, len(m1_colored_parts), 4): # Print 4 words per line
        print(" ".join(m1_colored_parts[i:i+4]))
    
    print("\nM2:")
    for i in range(0, len(m2_colored_parts), 4): # Print 4 words per line
        print(" ".join(m2_colored_parts[i:i+4]))

def main():
    m1_hex = read_hex_from_file("m1.txt")
    m2_hex = read_hex_from_file("m2.txt")

    if m1_hex is None or m2_hex is None:
        print("Exiting due to file reading errors.")
        return

    # Compare and print the messages themselves with colors
    compare_and_print_messages_colored(m1_hex, m2_hex)

    # Convert hex messages to bytes for hashing
    try:
        m1_bytes = binascii.unhexlify(m1_hex)
        m2_bytes = binascii.unhexlify(m2_hex)
    except binascii.Error:
        # This error should have been caught by read_hex_from_file's int(hex,16) validation,
        # but as a safeguard.
        print(f"{COLOR_RED}Error: Could not convert one or both hex strings to bytes for hashing.{COLOR_RESET}")
        return

    # Calculate MD4 hashes
    print("\n--- Calculating and Comparing MD4 Hashes ---")
    hash_m1 = calculate_md4(m1_bytes)
    hash_m2 = calculate_md4(m2_bytes)

    print(f"MD4 Hash of M1: {hash_m1}")
    print(f"MD4 Hash of M2: {hash_m2}")

    if hash_m1 == hash_m2:
        print(f"\nHashes are identical: {COLOR_GREEN}{hash_m1}{COLOR_RESET}")
        print(f"{COLOR_GREEN}SUCCESS: Collision confirmed!{COLOR_RESET}")
    else:
        print(f"\n{COLOR_RED}Hashes are DIFFERENT.{COLOR_RESET}")
        print(f"{COLOR_RED}FAILURE: No collision for these messages.{COLOR_RESET}")

if __name__ == "__main__":
    main()


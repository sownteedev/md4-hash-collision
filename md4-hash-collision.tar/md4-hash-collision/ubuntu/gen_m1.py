# encoding: utf-8
import random
import struct
import time
import re
import binascii

# MD4 HELPER FUNCTIONS (Core MD4 logic)
def endian_unpack(byte_string):
    """Converts a byte string (little endian) to a list of 32-bit unsigned integers."""
    return [struct.unpack('<I', bytes(byte_string[i:i+4]))[0] for i in range(0, len(byte_string), 4)]

def left_rotate(n, b):
    """Circular left rotate for a 32-bit unsigned integer."""
    return ((n << b) | (n >> (32 - b))) & 0xffffffff

def right_rotate(n, b):
    """Circular right rotate for a 32-bit unsigned integer."""
    return ((n >> b) | (n << (32 - b))) & 0xffffffff

def F(x, y, z):
    """MD4 Boolean function F."""
    return (x & y) | (~x & z)

def G(x, y, z):
    """MD4 Boolean function G."""
    return (x & y) | (x & z) | (y & z)

def H(x, y, z):
    """MD4 Boolean function H."""
    return x ^ y ^ z

def FF_std(a, b, c, d, k, s, X):
    """MD4 standard round 1 function."""
    res = (a + F(b, c, d) + X[k]) & 0xffffffff
    return left_rotate(res, s)

def GG_std(a, b, c, d, k, s, X):
    """MD4 standard round 2 function."""
    res = (a + G(b, c, d) + X[k] + 0x5a827999) & 0xffffffff
    return left_rotate(res, s)

def HH_std(a, b, c, d, k, s, X):
    """MD4 standard round 3 function."""
    res = (a + H(b, c, d) + X[k] + 0x6ed9eba1) & 0xffffffff
    return left_rotate(res, s)

def calculate_md4(message_bytes):
    """Calculates the MD4 hash of a given byte string."""
    h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476] # Initial hash values

    original_byte_len = len(message_bytes)
    original_bit_len = original_byte_len * 8

    # Pre-processing (Padding)
    message_padded_array = bytearray(message_bytes)
    message_padded_array += b'\x80' # Append '1' bit
    
    padding_len = (56 - (original_byte_len + 1) % 64) % 64
    message_padded_array += b'\x00' * padding_len
    
    message_padded_array += struct.pack('<Q', original_bit_len)
    
    processed_message_bytes = bytes(message_padded_array)

    # Process the message in 512-bit (64-byte) chunks
    for i in range(0, len(processed_message_bytes), 64):
        chunk = processed_message_bytes[i:i+64]
        X = endian_unpack(chunk)

        A, B, C, D = h[0], h[1], h[2], h[3]

        # Round 1
        s1 = [3, 7, 11, 19]
        for j in range(16):
            if j % 4 == 0: A = FF_std(A, B, C, D, j, s1[j%4], X)
            elif j % 4 == 1: D = FF_std(D, A, B, C, j, s1[j%4], X)
            elif j % 4 == 2: C = FF_std(C, D, A, B, j, s1[j%4], X)
            elif j % 4 == 3: B = FF_std(B, C, D, A, j, s1[j%4], X)
        
        # Round 2
        s2 = [3, 5, 9, 13]
        k_order_g = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
        for j in range(16):
            idx = k_order_g[j]
            if j % 4 == 0: A = GG_std(A, B, C, D, idx, s2[j%4], X)
            elif j % 4 == 1: D = GG_std(D, A, B, C, idx, s2[j%4], X)
            elif j % 4 == 2: C = GG_std(C, D, A, B, idx, s2[j%4], X)
            elif j % 4 == 3: B = GG_std(B, C, D, A, idx, s2[j%4], X)

        # Round 3
        s3 = [3, 9, 11, 15]
        k_order_h = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
        for j in range(16):
            idx = k_order_h[j]
            if j % 4 == 0: A = HH_std(A, B, C, D, idx, s3[j%4], X)
            elif j % 4 == 1: D = HH_std(D, A, B, C, idx, s3[j%4], X)
            elif j % 4 == 2: C = HH_std(C, D, A, B, idx, s3[j%4], X)
            elif j % 4 == 3: B = HH_std(B, C, D, A, idx, s3[j%4], X)

        h[0] = (h[0] + A) & 0xffffffff
        h[1] = (h[1] + B) & 0xffffffff
        h[2] = (h[2] + C) & 0xffffffff
        h[3] = (h[3] + D) & 0xffffffff

    return "".join(struct.pack('<I', val).hex() for val in h)

# COLLISION FINDING SPECIFIC FUNCTIONS
def FF(a, b, c, d, k, s, X_list):
    res = (a + F(b, c, d) + X_list[k]) & 0xffffffff
    return left_rotate(res, s)

def GG(a, b, c, d, k, s, X_list):
    res = (a + G(b, c, d) + X_list[k] + 0x5a827999) & 0xffffffff
    return left_rotate(res, s)

def HH(a, b, c, d, k, s, X_list): # Not directly used in this specific attack variant but good to have
    res = (a + H(b, c, d) + X_list[k] + 0x6ed9eba1) & 0xffffffff
    return left_rotate(res, s)

def modify_first_round_with_constraints(abcd_state, j_idx, i_idx, s_val, x_words, constraint_list):
    v = left_rotate((abcd_state[j_idx % 4] + F(abcd_state[(j_idx + 1) % 4], abcd_state[(j_idx + 2) % 4], abcd_state[(j_idx + 3) % 4]) + x_words[i_idx]) & 0xffffffff, s_val)
    for constraint in constraint_list:
        if constraint[0] == '=':
            v ^= (v ^ abcd_state[(j_idx + 1) % 4]) & (2 ** constraint[1])
        elif constraint[0] == '0':
            v &= ~(2 ** constraint[1])
        elif constraint[0] == '1':
            v |= (2 ** constraint[1])
    x_words[i_idx] = (right_rotate(v, s_val) - abcd_state[j_idx % 4] - F(abcd_state[(j_idx + 1) % 4], abcd_state[(j_idx + 2) % 4], abcd_state[(j_idx + 3) % 4])) % 2**32
    abcd_state[j_idx % 4] = v

def find_candidate_m1_from_initial(initial_message_block_bytes):
    x_words = endian_unpack(initial_message_block_bytes)
    initial_abcd = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
    abcd_current = initial_abcd[:]

    constraints_round1 = [
        [['=', 6]], [['0', 6], ['=', 7], ['=', 10]],
        [['1', 6], ['1', 7], ['0', 10], ['=', 25]],
        [['1', 6], ['0', 7], ['0', 10], ['0', 25]],
        [['1', 7], ['1', 10], ['0', 25], ['=', 13]],
        [['0', 13], ['=', 18], ['=', 19], ['=', 20], ['=', 21], ['1', 25]],
        [['=', 12], ['0', 13], ['=', 14], ['0', 18], ['0', 19], ['1', 20], ['0', 21]],
        [['1', 12], ['1', 13], ['0', 14], ['=', 16], ['0', 18], ['0', 19], ['0', 20], ['0', 21]],
        [['1', 12], ['1', 13], ['1', 14], ['0', 16], ['0', 18], ['0', 19], ['0', 20], ['=', 22], ['1', 21], ['=', 25]],
        [['1', 12], ['1', 13], ['1', 14], ['0', 16], ['0', 19], ['1', 20], ['1', 21], ['0', 22], ['1', 25], ['=', 29]],
        [['1', 16], ['0', 19], ['0', 20], ['0', 21], ['0', 22], ['0', 25], ['1', 29], ['=', 31]],
        [['0', 19], ['1', 20], ['1', 21], ['=', 22], ['1', 25], ['0', 29], ['0', 31]],
        [['0', 22], ['0', 25], ['=', 26], ['=', 28], ['1', 29], ['0', 31]],
        [['0', 22], ['0', 25], ['1', 26], ['1', 28], ['0', 29], ['1', 31]],
        [['=', 18], ['1', 22], ['1', 25], ['0', 26], ['0', 28], ['0', 29]],
        [['0', 18], ['=', 25], ['1', 26], ['1', 28], ['0', 29], ['=', 31]]
    ]
    shift_values = [3, 7, 11, 19] * 4
    change_order = [0, 3, 2, 1] * 4
    for i in range(16):
        modify_first_round_with_constraints(abcd_current, change_order[i], i, shift_values[i], x_words, constraints_round1[i])

    constraints_round2 = [
        [['=', 18, 2], ['1', 25], ['0', 26], ['1', 28], ['1', 31]],
        [['=', 18, 0], ['=', 25, 1], ['=', 26, 1], ['=', 28, 1], ['=', 31, 1]]
    ]

    a5 = GG(abcd_current[0], abcd_current[1], abcd_current[2], abcd_current[3], 0, 3, x_words)
    for constraint in constraints_round2[0]:
        if constraint[0] == '=': a5 ^= ((a5 ^ abcd_current[constraint[2]]) & (2 ** constraint[1]))
        elif constraint[0] == '0': a5 &= ~(2 ** constraint[1])
        elif constraint[0] == '1': a5 |= (2 ** constraint[1])
    q0_val = (right_rotate(a5, 3) - abcd_current[0] - G(abcd_current[1], abcd_current[2], abcd_current[3]) - 0x5a827999) % 2**32

    original_x0 = x_words[0]
    x_words[0] = q0_val
    A0, B0, C0, D0 = initial_abcd
    A_prime = FF(A0, B0, C0, D0, 0, 3, x_words)
    x_words[0] = original_x0
    
    A1 = FF(A0, B0, C0, D0, 0, 3, x_words)
    D1 = FF(D0, A1, B0, C0, 1, 7, x_words)
    x_words[1] = (right_rotate(D1, 7) - D0 - F(A_prime, B0, C0)) % 2**32
    C1 = FF(C0, D1, A1, B0, 2, 11, x_words)
    x_words[2] = (right_rotate(C1, 11) - C0 - F(D1, A_prime, B0)) % 2**32
    B1 = FF(B0, C1, D1, A1, 3, 19, x_words)
    x_words[3] = (right_rotate(B1, 19) - B0 - F(C1, D1, A_prime)) % 2**32
    A2_calc = FF(A1, B1, C1, D1, 4, 3, x_words)
    x_words[4] = (right_rotate(A2_calc, 3) - A_prime - F(B1, C1, D1)) % 2**32
    
    x_words[0] = q0_val
    abcd_current[0] = a5

    d5 = GG(abcd_current[3], abcd_current[0], abcd_current[1], abcd_current[2], 4, 5, x_words)
    for constraint in constraints_round2[1]:
        if constraint[0] == '=': d5 ^= ((d5 ^ abcd_current[constraint[2]]) & (2 ** constraint[1]))
        elif constraint[0] == '0': d5 &= ~(2 ** constraint[1])
        elif constraint[0] == '1': d5 |= (2 ** constraint[1])
    q4_val = (right_rotate(d5, 5) - abcd_current[3] - G(abcd_current[0], abcd_current[1], abcd_current[2]) - 0x5a827999) % 2**32

    A, B, C, D = initial_abcd
    A = FF(A, B, C, D, 0, 3, x_words)
    D = FF(D, A, B, C, 1, 7, x_words)
    C = FF(C, D, A, B, 2, 11, x_words)
    B = FF(B, C, D, A, 3, 19, x_words)

    x_words_temp_for_A2_prime = x_words[:]
    x_words_temp_for_A2_prime[4] = q4_val
    A2_prime = FF(A, B, C, D, 4, 3, x_words_temp_for_A2_prime)

    A2 = FF(A, B, C, D, 4, 3, x_words)
    D2 = FF(D, A2, B, C, 5, 7, x_words)
    x_words[5] = (right_rotate(D2, 7) - D - F(A2_prime, B, C)) % 2**32
    C2 = FF(C, D2, A2, B, 6, 11, x_words)
    x_words[6] = (right_rotate(C2, 11) - C - F(D2, A2_prime, B)) % 2**32
    B2 = FF(B, C2, D2, A2, 7, 19, x_words)
    x_words[7] = (right_rotate(B2, 19) - B - F(C2, D2, A2_prime)) % 2**32
    A3 = FF(A2, B2, C2, D2, 8, 3, x_words)
    x_words[8] = (right_rotate(A3, 3) - A2_prime - F(B2, C2, D2)) % 2**32
    x_words[4] = q4_val

    m1_bytes = b''.join([struct.pack('<I', val) for val in x_words])
    
    # Internal check: does this M1 form a collision with its M2 counterpart?
    m2_counterpart_bytes = _create_colliding_block_from_internal(m1_bytes)
    if calculate_md4(m1_bytes) == calculate_md4(m2_counterpart_bytes) and m1_bytes != m2_counterpart_bytes:
        return m1_bytes
    return None

def _create_colliding_block_from_internal(message_bytes):
    """Helper for internal verification. Creates M2 from M1."""
    x_words_prime = list(endian_unpack(message_bytes))
    x_words_prime[1] = (x_words_prime[1] + (2 ** 31)) % 2**32
    x_words_prime[2] = (x_words_prime[2] + ((2 ** 31) - (2 ** 28))) % 2**32
    x_words_prime[12] = (x_words_prime[12] - (2 ** 16)) % 2**32
    return b''.join([struct.pack('<I', val) for val in x_words_prime])


def main_generate_m1_candidate_file():
    """Generates a candidate M1 block and saves it to m1.txt."""
    print('[+] Searching for a candidate M1 for MD4 collision...')
    attempt_num = 1
    m1_candidate_bytes = None
    start_time_search = time.perf_counter()

    while m1_candidate_bytes is None:
        initial_message_bytes = bytes([random.randint(0, 255) for _ in range(64)])
        
        m1_candidate_bytes = find_candidate_m1_from_initial(initial_message_bytes)
        
        if m1_candidate_bytes:
            search_duration = round(time.perf_counter() - start_time_search, 2)
            print(f"\nCandidate M1 found on attempt {attempt_num} (took {search_duration}s for this attempt).")
            break
        
        attempt_num += 1
        if attempt_num % 10 == 0:
            current_search_duration = round(time.perf_counter() - start_time_search, 2)
            print(f"Still searching for M1 candidate... attempts: {attempt_num}, total search time: {current_search_duration}s")
    
    if m1_candidate_bytes:
        m1_hex = binascii.hexlify(m1_candidate_bytes).decode()
        try:
            with open("m1.txt", "w") as f:
                f.write(m1_hex)
            print(f"Candidate M1 (hex) saved to m1.txt")
            hash_m1 = calculate_md4(m1_candidate_bytes) # Calculate hash for reference
            print(f"MD4 Hash of this M1: {hash_m1}")
            print("\nYou can now use m1.txt as input for the second script.")
        except IOError:
            print("Error: Could not write M1 to m1.txt. Please check permissions.")
            print(f"Generated Candidate M1 (hex): {m1_hex}") # Print to console as fallback
    else:
        print("\nFailed to generate a candidate M1 after many attempts.")

if __name__ == "__main__":
    total_start_time = time.perf_counter()
    main_generate_m1_candidate_file()
    total_end_time = time.perf_counter()
    print(f"\n[!] M1 generation process finished in {round(total_end_time - total_start_time, 2)} seconds overall.")
